export { default as ResizableTabsReview } from './ResizableTabsReview';
