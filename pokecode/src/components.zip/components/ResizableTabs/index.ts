export { default as ResizableTabs } from './ResizableTabs';
