export { default as DesignedButton } from './DesignedButton';
export { default as DesignedButton1 } from './DesignedButton1';
