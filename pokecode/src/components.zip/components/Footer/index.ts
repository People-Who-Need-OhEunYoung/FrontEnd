export { default as Footer } from './Footer';
export { Footer1 } from './Footer';
